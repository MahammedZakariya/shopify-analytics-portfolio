# Shopify Analytics Portfolio — Project 1: Revenue & Growth Dashboard

This repository template helps you build a **Power BI dashboard** using **real Shopify data** (orders, line items, products, customers).  
It is designed for junior/entry-level data roles to showcase *end-to-end* skills: cleaning → modeling → DAX → insights.

> ⚠️ **Privacy first:** Do **not** commit any personally identifiable information (PII). Keep `/data_raw` untracked. Only publish anonymized or aggregated samples.

---

## Folder structure
```
.
├── data_raw/        # your Shopify CSV exports (never commit)
├── data_clean/      # cleaned/anonymized CSVs for modeling
├── powerbi/         # .pbix files and exported visuals
├── sql/             # optional SQL used for modeling/validation
├── notebooks/       # optional Jupyter notebooks
├── decks/           # slides for storytelling (PDF/PPTX)
├── reports/         # written insights/memos
└── docs/            # data dictionary, decisions, and notes
```

## Step-by-step (checklist)
- [ ] 1. **Export Shopify CSVs** (Orders, Products, Customers; optional: Discounts/Transactions) into `data_raw/`.
- [ ] 2. **Remove PII** (names, emails, phone). Keep `customer_id` only.
- [ ] 3. **Create cleaned files** in `data_clean/` with consistent headers and datatypes.
- [ ] 4. **Build Power BI model** (import CSVs, relationships, Date table).
- [ ] 5. **Add DAX measures** (Revenue, NetRevenue, Orders, AOV, MoM, 30D MA).
- [ ] 6. **Create visuals** (KPI cards, trends, top products, map, slicers).
- [ ] 7. **Validate** against quick Excel sums (spot-check).
- [ ] 8. **Write insights** (3–5 bullets) and export one hero screenshot to `powerbi/`.
- [ ] 9. **Publish**: add slides to `decks/` and update this README with results.

## Data dictionary (starter)
See `docs/data_dictionary.md` for suggested fields to keep.

## DAX starter (copy/paste)
See `powerbi/measures_dax.txt` for common measures.

## License
MIT — use and adapt freely.

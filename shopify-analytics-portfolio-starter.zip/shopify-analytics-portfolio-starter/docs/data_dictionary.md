# Data Dictionary (starter)

Keep only the fields needed for analysis and remove PII.

## Orders / Line Items (single row per line item)
- order_id (text)
- order_name (text)
- created_at (datetime)
- fulfillment_status (text)
- financial_status (text)
- customer_id (text)
- lineitem_sku (text)
- lineitem_name (text)
- lineitem_quantity (integer)
- lineitem_price (decimal)      # unit price before discount
- lineitem_discount (decimal)   # discount £ applied to the line
- lineitem_refund (decimal)     # refunded £ on the line (0 if none)
- currency (text)
- shipping_country (text)       # or shipping_province/city
- channel (text)                # e.g., online store, POS, etc.

## Products
- sku (text)
- title (text)
- product_type (text)
- vendor (text)
- price (decimal)
- cost (decimal)                # optional COGS for margin analysis

## Customers
- customer_id (text)
- created_at (datetime)         # first seen
- orders_count (integer)
- total_spent (decimal)
- country (text)

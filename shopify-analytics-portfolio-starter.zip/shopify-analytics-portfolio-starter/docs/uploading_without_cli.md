# Contributing / Uploading to GitHub (no CLI)

1. Go to your repository on GitHub.
2. Click **Add file ▸ Upload files**.
3. Drag-and-drop folders from this starter into the repo (GitHub will create folders).
4. Commit with a clear message, e.g., `chore: add starter kit`.
5. For updates, repeat the upload or use Git locally if you prefer.

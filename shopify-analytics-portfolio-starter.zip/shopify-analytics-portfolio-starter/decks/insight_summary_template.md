# Executive Dashboard — Insight Summary (Template)

**Business Context:** Briefly state what this dashboard answers (e.g., revenue momentum, AOV, top products).

## Key KPIs (latest period)
- Net Revenue: £___ (MoM: __% | YoY: __%)
- Orders: ___
- AOV: £___
- Refund Rate: __%

## Top Insights (3–5 bullets)
1. 
2. 
3. 

## Recommended Actions
- 
- 

## Appendix
- Data sources
- Caveats/Assumptions
